#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main() {
    pid_t pid;
    int fd;

    fd = open("pid_file.txt", O_CREAT | O_WRONLY | O_APPEND, 0644);
    if (fd == -1) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid < 0) {
        perror("forking failed");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        char child_pid_str[16];
        sprintf(child_pid_str, "child process id: %d\n", getpid());
        write(fd, child_pid_str, strlen(child_pid_str));
        close(fd);
        exit(EXIT_SUCCESS);
    } else {
        char parent_pid_str[16];
        sprintf(parent_pid_str, "parent process id: %d\n", getpid());
        write(fd, parent_pid_str, strlen(parent_pid_str));
        close(fd);
        wait(NULL);
        exit(EXIT_SUCCESS);
    }
}
