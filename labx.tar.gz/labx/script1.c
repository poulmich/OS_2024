#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

#define n 3

int main() {
    pid_t pid;
    int i;

    for (i = 0; i < n; i++) {
        pid = fork();

        if (pid < 0) {
            perror("forking failed");
            exit(1);
        } else if (pid == 0) {
            printf("child %d process id : %d\n", i + 1, getpid());
            exit(0);
        }
    }

    // parent process
    for(i = 0; i < n; i++) {
        wait(NULL); //
    }

    printf("parent process id: %d\n", getpid());

    return 0;
}
