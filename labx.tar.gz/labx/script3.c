#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void signal_handler(int signum) {
    printf("child received signal: %d\n", signum);
}

int main() {
    pid_t child_pid;

    child_pid = fork();

    if (child_pid < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0) {
        signal(SIGUSR1, signal_handler);

        pause();

        printf("child exiting..\n");
        exit(EXIT_SUCCESS);

    } else {
        kill(child_pid, SIGUSR1);
        printf("parent sent signal: SIGUSR1\n");
        wait(NULL);

        exit(EXIT_SUCCESS);
    }
}
