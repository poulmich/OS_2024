
#include <stdio.h>

void add(int *a, int *b, int *c, int *sum) {
    *sum = *a + *b + *c;
}

int main() {
    int num1, num2, num3, result;

    printf("enter three integers: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    add(&num1, &num2, &num3, &result);

    printf("sum: %d\n", result);

    return 0;
}
