#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

#define BUFFER_SIZE 1024

int main() {
    int pipefd[2];
    pid_t child_pid;


    if (pipe(pipefd) == -1) {
        perror("pipe creation failed");
        exit(EXIT_FAILURE);
    }


    child_pid = fork();

    if (child_pid < 0) {
        perror("forking failed");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0) {
        close(pipefd[1]);

        char buffer[BUFFER_SIZE];
        ssize_t bytes_read;

        while (1) {
            bytes_read = read(pipefd[0], buffer, BUFFER_SIZE);
            if (bytes_read <= 0) {
                break;
            }
            buffer[bytes_read] = '\0';
            printf("child received this: %s\n", buffer);
        }

        close(pipefd[0]);
        exit(EXIT_SUCCESS);

    } else {
        close(pipefd[0]);

        char message[] = "greetings from parent process!";
        write(pipefd[1], message, strlen(message) + 1);
        printf("parent sent: %s\n", message);

        strcpy(message, "new signal from parent.");
        write(pipefd[1], message, strlen(message) + 1);
        printf("parent sent this: %s\n", message);

        close(pipefd[1]);

        wait(NULL);

        exit(EXIT_SUCCESS);
    }
}
