#!/bin/bash
date
date +%s 
current_time=$(date +"%s")
let "current_time_double = current_time * 2"
echo "Current time in seconds: $current_time"
echo "Current time doubled: $current_time_double"
for((i=0;i<20;i++));do
  echo $((i+1))
done
